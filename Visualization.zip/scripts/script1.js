
Cesium.Ion.defaultAccessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI3YmY4M2E2Yi0wZWEyLTRhNjEtOWM4NC1jZWM2YTg5ODkyN2YiLCJpZCI6MTM1MzQwLCJpYXQiOjE3MDE4OTc5NDB9.Mg8y7RT7XQ9fl_fySRQSxiJLFpWbXPWo6A04uGjsXLc';

const viewer = new Cesium.Viewer('cesiumContainer', {
    terrain: Cesium.Terrain.fromWorldTerrain(),
});
viewer.scene.logarithmicDepthBuffer = false;
viewer.imageryLayers.removeAll();
viewer.imageryLayers.addImageryProvider(new Cesium.OpenStreetMapImageryProvider({
    url: 'https://cartodb-basemaps-1.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png',
}));

viewer.camera.flyTo({
    destination: Cesium.Cartesian3.fromDegrees(-122.4194, 37.755, 800),
    orientation: {
        heading: Cesium.Math.toRadians(0.0),
        pitch: Cesium.Math.toRadians(-15.0),
    }
});

var geoJsonGrid = {
    type: 'FeatureCollection',
    features: []
};

var gridWidth = 0.01;  // 
var gridHeight = 0.01; 
var cellSize = 0.001;  

for (var x = -gridWidth / 2; x <= gridWidth / 2; x += cellSize) {
    for (var y = -gridHeight / 2; y <= gridHeight / 2; y += cellSize) {
        var feature = {
            type: 'Feature',
            properties: {
                index: geoJsonGrid.features.length, 
            },
            geometry: {
                type: 'Polygon',
                coordinates: [[
                    [-122.4194 + x, 37.7749 + y, 0],
                    [-122.4194 + x + cellSize, 37.7749 + y, 0],
                    [-122.4194 + x + cellSize, 37.7749 + y + cellSize, 0],
                    [-122.4194 + x, 37.7749 + y + cellSize, 0],
                    [-122.4194 + x, 37.7749 + y, 0]
                ]]
            }
        };

        geoJsonGrid.features.push(feature);
    }
}

var dataSource = Cesium.GeoJsonDataSource.load(geoJsonGrid, {
    clampToGround: true,
   
});

dataSource.then(function (dataSource) {
    var entities = dataSource.entities.values;

    for (var i = 0; i < entities.length; i++) {
        var entity = entities[i];
        var originalPolygon = entity.polygon;
        var originalHierarchy = originalPolygon.hierarchy.getValue(Cesium.JulianDate.now());

        viewer.entities.add({
            polygon: {
                hierarchy: originalHierarchy,
                material: Cesium.Color.WHITE.withAlpha(0.5),
                heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
            }
        });
    }
 
    viewer.zoomTo(dataSource.entities);
});


const geojsonUrl = '../data/tfl/tfl_lines.geojson'; 

function loadGeoJsonData() {
  Cesium.GeoJsonDataSource.load(geojsonUrl).then(function(dataSource) {
    viewer.dataSources.add(dataSource); 

    viewer.zoomTo(dataSource);
  }).otherwise(function(error) {
    console.error("Error loading GeoJSON: ", error);
  });
}

document.getElementById("#seeTubes").addEventListener("click", loadGeoJsonData);



var handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
var highlightedEntity = undefined;
handler.setInputAction(function (movement) {
    // Check for hover over entities
    var pickedObject = viewer.scene.pick(movement.endPosition);
    if (Cesium.defined(pickedObject) && Cesium.defined(pickedObject.id)) {
      
        if (highlightedEntity !== pickedObject.id) {
            if (highlightedEntity) {
                highlightedEntity.polygon.material = Cesium.Color.RED.withAlpha(0.5);
            }
            highlightedEntity = pickedObject.id;
            pickedObject.id.polygon.material = Cesium.Color.YELLOW.withAlpha(0.5);
        }
    } else {
        // If not hovering over any cell, reset the color
        if (highlightedEntity) {
            highlightedEntity.polygon.material = Cesium.Color.RED.withAlpha(0.5);
            highlightedEntity = undefined;
        }
    }
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

handler.setInputAction(function (movement) {
    var pickedObject = viewer.scene.pick(movement.position);
    if (Cesium.defined(pickedObject) && Cesium.defined(pickedObject.id)) {
        console.log("Clicked on cell number: ", pickedObject.id.properties.index);
    }
}, Cesium.ScreenSpaceEventType.LEFT_CLICK);

function getRandomCellCoordinates() {
    var randomX = -gridWidth / 2 + Math.random() * gridWidth;
    var randomY = -gridHeight / 2 + Math.random() * gridHeight;

    return {
        longitude: -122.4194 + randomX,
        latitude: 37.7749 + randomY,
        height: 0
    };
}

function placeModelOnRandomCell() {
    var randomCellCoordinates = getRandomCellCoordinates();

    const entity = viewer.entities.add({
        name: 'Random Model',
        position: Cesium.Cartesian3.fromDegrees(randomCellCoordinates.longitude, randomCellCoordinates.latitude, randomCellCoordinates.height-2),
        model: {
            uri: '../data/tree.glb',
            scale: 0.5,
        },
      
    });
}

async function showBuildings() {
    const buildingTileset = await Cesium.createOsmBuildingsAsync();
    viewer.scene.primitives.add(buildingTileset);
}
